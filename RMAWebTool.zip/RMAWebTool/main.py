#RMA MANAGEMENT SERVER
#Developed and designed by Gonzalo Patino




import requests
import openpyxl
from openpyxl import Workbook
from datetime import datetime
from openpyxl.styles import NamedStyle

user_info_dict = {}  # Global dictionary to store user information
address_dict = {}    # Global dictionary to store address components

class Customer:
    def __init__(self):
        self.customerID = None
        self.customerContactName = None
        self.customerEmail = None
        self.customerPhoneNumber = None
        self.customerCompanyName = None
        self.customerStreetInfo = None
        self.customerCity = None
        self.customerState = None
        self.customerZipCode = None
        self.customerCountry = None

    # CustomerID Getter and Setter
    @property
    def customerID(self):
        return self._customerID

    @customerID.setter
    def customerID(self, value):
        # Add validation if needed
        self._customerID = value

    # customerContactName Getter and Setter
    @property
    def customerContactName(self):
        return self._customerContactName

    @customerContactName.setter
    def customerContactName(self, value):
        # Add validation if needed
        self._customerContactName = value

    # customerEmail Getter and Setter
    @property
    def customerEmail(self):
        return self._customerEmail

    @customerEmail.setter
    def customerEmail(self, value):
        # Add validation if needed
        self._customerEmail = value

    # customerPhoneNumber Getter and Setter
    @property
    def customerPhoneNumber(self):
        return self._customerPhoneNumber

    @customerPhoneNumber.setter
    def customerPhoneNumber(self, value):
        # Add validation if needed
        self._customerPhoneNumber = value

    # customerCompanyName Getter and Setter
    @property
    def customerCompanyName(self):
        return self._customerCompanyName

    @customerCompanyName.setter
    def customerCompanyName(self, value):
        # Add validation if needed
        self._customerCompanyName = value

    # customerStreetInfo Getter and Setter
    @property
    def customerStreetInfo(self):
        return self._customerStreetInfo

    @customerStreetInfo.setter
    def customerStreetInfo(self, value):
        # Add validation if needed
        self._customerStreetInfo = value

    # customerCity Getter and Setter
    @property
    def customerCity(self):
        return self._customerCity

    @customerCity.setter
    def customerCity(self, value):
        # Add validation if needed
        self._customerCity = value

    # customerState Getter and Setter
    @property
    def customerState(self):
        return self._customerState

    @customerState.setter
    def customerState(self, value):
        # Add validation if needed
        self._customerState = value

     # customerZipCode Getter and Setter
    @property
    def customerZipCode(self):
        return self._customerZipCode

    @customerZipCode.setter
    def customerZipCode(self, value):
        # Add validation if needed
        self._customerZipCode = value

      # customerCountry Getter and Setter
    @property
    def customerCountry(self):
        return self._customerCountry

    @customerCountry.setter
    def customerCountry(self, value):
        # Add validation if needed
        self._customerCountry = value

    def __str__(self):
        # Use a four-digit year for consistency
        return f"Customer ID: {self.customerID}, Contact name: {self.customerContactName}, Email: {self.customerEmail}, Phone number: {self.customerPhoneNumber}, Company name: {self.customerCompanyName}, Street info: {self.customerStreetInfo}, City: {self.customerCity}, Zip code: {self.customerZipCode}, Country: {self.customerCountry}"


#fixme: change ZendeskClient to ZendeskAPIconnection
class ZendeskClient:
    def __init__(self, subdomain, email, password):
        self.subdomain = subdomain
        self.email = email
        self.password = password
        self.base_url = f'https://{subdomain}.zendesk.com/api/v2/'

    def test_api_connection(self):
        """Method to test basic communication with the Zendesk API."""
        url = self.base_url + 'users/me.json'  # Endpoint to fetch current user's details
        try:
            response = requests.get(url, auth=(self.email, self.password))
            if response.status_code == 200:
                print("Connection successfully established to Zendesk API for Cadex Electronics")
                #print(response.json()) #If you want to see the Json response
                return True
            else:
                print(f"Connection failed. Status code: {response.status_code}")
                return False
        except requests.exceptions.RequestException as e:
            print(f"Error occurred: {e}")
            return False

    def search_user_by_email(self, email, customer_instance):
        global user_info_dict  # Refer to the global user information dictionary
        url = self.base_url + f'users/search.json?query=email:{email}'
        try:
            response = requests.get(url, auth=(self.email, self.password))
            if response.status_code == 200:
                users = response.json()['users']

                if users:
                    user = users[0]  # Assuming you want the first user's info
                    user_info_dict['id'] = user.get('id')
                    customer_instance.customerID = user_info_dict['id']

                    user_info_dict['name'] = user.get('name')
                    customer_instance.customerContactName = user_info_dict['name']

                    user_info_dict['email'] = user.get('email')
                    customer_instance.customerEmail = user_info_dict['email']

                    user_info_dict['phone'] = user.get('phone', 'No phone number')
                    customer_instance.customerPhoneNumber = user_info_dict['phone']

                return users
            else:
                print(f"Failed to retrieve users. Status code: {response.status_code}")
                return None
        except requests.exceptions.RequestException as e:
            print(f"Error occurred: {e}")
            return None

    def get_organization_address(self, organization_id,  customer_instance):
        global address_dict  # Refer to the global dictionary
        url = self.base_url + f'organizations/{organization_id}.json'
        try:
            response = requests.get(url, auth=(self.email, self.password))
            if response.status_code == 200:
                organization = response.json()['organization']
                print(f"Organization name: {organization.get('name')}")
                customer_instance.customerCompanyName = organization.get('name')

                full_address = organization.get('details', '')  # Extract full address from 'details' field

                # Split the address into components
                address_parts = full_address.split(', ')
                if len(address_parts) > 2:
                    # Split the State and Zip Code
                    state_zip = address_parts[2].split(' ')

                    address_dict['address'] = address_parts[0]
                    customer_instance.customerStreetInfo = address_dict['address']

                    address_dict['city'] = address_parts[1]
                    customer_instance.customerCity = address_dict['city']

                    address_dict['state'] = state_zip[0] if len(state_zip) > 0 else None
                    customer_instance.customerState = address_dict['state']

                    address_dict['zip_code'] = state_zip[1] if len(state_zip) > 1 else None
                    customer_instance.customerZipCode = address_dict['zip_code']

                    address_dict['country'] = address_parts[3] if len(address_parts) > 3 else None
                    customer_instance.customerCountry = address_dict['country']

                return full_address

            else:
                print(f"Failed to retrieve organization. Status code: {response.status_code}")
                return None
        except requests.exceptions.RequestException as e:
            print(f"Error occurred: {e}")
            return None

class RMAmanagement:
    #Constructor
    def __init__(self):
        self.RMAID = None
        self.RMAcategory = None
        self.DateCalled = None
        self.CustomerComplaint = None
        self.CadexReply = None
        self.RMAcomments = None
        self.RMAsignature = None
        self.RMAcondition = None
        self.Product = None
        self.Status = None
        self.DecontaminationStatus = None
        self.ProductSerialNumber = None

    # RMAID Getter and Setter
    @property
    def RMAID(self):
        return self._RMAID

    @RMAID.setter
    def RMAID(self, value):
        # Add validation if needed
        self._RMAID = value

    # RMAcategory Getter and Setter
    @property
    def RMAcategory(self):
        return self._RMAcategory

    @RMAcategory.setter
    def RMAcategory(self, value):
        # Add validation if needed
        self._RMAcategory = value

    # DateCalled Getter and Setter
    @property
    def DateCalled(self):
        return self._DateCalled

    @DateCalled.setter
    def DateCalled(self, value):
        # Add validation if needed
        self._DateCalled = value

    # CustomerComplaint Getter and Setter
    @property
    def CustomerComplaint(self):
        return self._CustomerComplaint

    @CustomerComplaint.setter
    def CustomerComplaint(self, value):
        # Add validation if needed
        self._CustomerComplaint = value

    # CadexReply Getter and Setter
    @property
    def CadexReply(self):
        return self._CadexReply

    @CadexReply.setter
    def CadexReply(self, value):
        # Add validation if needed
        self._CadexReply = value

    # RMAcomments Getter and Setter
    @property
    def RMAcomments(self):
        return self._RMAcomments

    @RMAcomments.setter
    def RMAcomments(self, value):
        # Add validation if needed
        self._RMAcomments = value

    # RMAsignature Getter and Setter
    @property
    def RMAsignature(self):
        return self._RMAsignature

    @RMAsignature.setter
    def RMAsignature(self, value):
        # Add validation if needed
        self._RMAsignature = value

    # RMAcondition Getter and Setter
    @property
    def RMAcondition(self):
        return self._RMAcondition

    @RMAcondition.setter
    def RMAcondition(self, value):
        # Add validation if needed
        self._RMAcondition = value

    # Product Getter and Setter
    @property
    def Product(self):
        return self._Product

    @Product.setter
    def Product(self, value):
        # Add validation if needed
        self._Product = value

    # Serial number Getter and Setter
    @property
    def ProductSerialNumber(self):
        return self._ProductSerialNumber

    @ProductSerialNumber.setter
    def ProductSerialNumber(self, value):
        # Add validation if needed
        self._ProductSerialNumber = value

    # Status Getter and Setter
    @property
    def Status(self):
        return self._Status

    @Status.setter
    def Status(self, value):
        # Add validation if needed
        self._Status = value

    # Decontamination status Getter and Setter
    @property
    def DecontaminationStatus (self):
        return self._DecontaminationStatus

    @DecontaminationStatus.setter
    def DecontaminationStatus(self, value):
        # Add validation if needed
        self._DecontaminationStatus = value

    def __str__(self):
        return (f"RMA ID: {self._RMAID}, Category: {self._RMAcategory}, Date Called: {self._DateCalled}, "
                f"Customer Complaint: {self._CustomerComplaint}, Cadex Reply: {self._CadexReply}, "
                f"Comments: {self._RMAcomments},Signature: {self.RMAsignature}, Condition: {self._RMAcondition}, Product: {self._Product}, Product Serial Number: {self._ProductSerialNumber}, Decontamination status: {self.DecontaminationStatus}, RMAstatus is {self.Status}")

    def update_excel_with_rma_info(self, RMA_instance, customer_instance):
        """
        Updates a macro-enabled Excel sheet (.xlsm) with incremented 'RMAnumber'.
        It finds the highest 'RMAnumber' in the specified sheet, increments it,
        and writes the incremented 'RMAnumber' and 'IDnumber' (first column) in the next row.

        The method uses a predefined file path and sheet name. Errors are handled
        appropriately for file not found or incorrect sheet name.

        Raises:
            Exception: If any error occurs during the process.
        """
        file_path = 'C:/Users/coleg/Desktop/SRNdb.xlsm'  # Update to your file path
        sheet_name = 'Customer_DB'  # Replace with your actual sheet name, or None if using the active sheet

        try:
            with open(file_path, "a"):
                pass
        except PermissionError:
            print("The Excel file is currently open. Please close it and try again.")
            return  # Stop the method if the file is open

        # Proceed if no exceptions were raised
        try:
            # Load the workbook with 'keep_vba' flag to preserve macros
            workbook = openpyxl.load_workbook(file_path, keep_vba=True)

            if sheet_name and sheet_name in workbook.sheetnames:
                sheet = workbook[sheet_name]
            else:
                raise ValueError(f"Sheet '{sheet_name}' not found in the workbook.")

            # Identifying the 'SRN' column
            rma_column = None
            for i, cell in enumerate(sheet[1]):
                if str(cell.value).strip() == "SRN":
                    rma_column = i + 1
                    break

            if rma_column is None:
                raise ValueError("Required column 'RMAnumber' not found")

            # Finding the highest 'RMAnumber'
            max_rma = 0
            max_rma_row = 0
            for row in sheet.iter_rows(min_row=2, min_col=rma_column, max_col=rma_column):
                cell = row[0].value
                if cell is not None and isinstance(cell, int) and cell > max_rma:
                    max_rma = cell
                    max_rma_row = row[0].row



            # Mapping column names to their respective indices
            column_indices = {}
            for i, cell in enumerate(sheet[1]):
                column_name = str(cell.value).strip()
                column_indices[column_name] = i + 1


            # Read the existing ID number from the same row as the highest 'RMAnumber'
            existing_id_number_cell = sheet.cell(row=max_rma_row, column=1)
            existing_id_number = existing_id_number_cell.value

            # Verify and increment the existing ID number
            next_id_number = existing_id_number + 1 if isinstance(existing_id_number, int) else 1

            # Increment 'IDnumber' and 'RMAnumber' and write to the next row
            next_row = max_rma_row + 1
            sheet.cell(row=next_row, column=1).value = next_id_number
            sheet.cell(row=next_row, column=rma_column).value = max_rma + 1

            #ADD ADDITIONAl fields to the excel sheet

            #Obtain a timestamp
            dateStamp = Timestamp()
            current_date = dateStamp.get_current_date()  # datetime object
            date_style = Timestamp.get_excel_date_style()  # NamedStyle object for Excel

            #This will be replaced by the HTML form with dropdown menus
            New_RMA_ID = max_rma + 1
            RMA_instance.RMAID = New_RMA_ID
            RMA_instance.DateCalled = current_date
            RMA_instance.Product = input("Insert the Product: ")
            RMA_instance.ProductSerialNumber = input("Insert the product serial number(s): ")
            RMA_instance.CustomerComplaint = input("Copy paste the customer complaint: ")
            RMA_instance.RMAcategory = input("Please insert the RMA category: ")
            RMA_instance.CadexReply = input("please insert the Cadex reply to the customer complaint")
            RMA_instance.RMAcondition = input("Please indicate whether it is brand new product or an old product")
            RMA_instance.RMAcomments = f"Please ship {RMA_instance.Product} with serial number(s):{RMA_instance.ProductSerialNumber}"
            RMA_instance.RMAsignature = "Thanks and Regards - Gonzalo Patino, Applications Engineer"
            RMA_instance.Status =  "FALSE"
            RMA_instance.DecontaminationStatus = input("Was this used in a medical environment? yes no: ")


            #Update RMAID is done

            #Update Date called
            date_called_column_index = column_indices.get('DateCalled')
            if date_called_column_index:
                date_called_cell = sheet.cell(row=next_row, column=date_called_column_index)
                date_called_cell.value = RMA_instance.DateCalled
                #date_called_cell.style = date_style

            # Update the "Product" column in the NEXT row with a new value
            product_column_index = column_indices.get('Product')
            if product_column_index:
                product_value = RMA_instance.Product
                sheet.cell(row=next_row, column=product_column_index).value = product_value

            # Update product serial number: not needed

            #Update customer complaint:
            # Update the "Customer complaint" column in the NEXT row with a new value
            customer_complaint_column_index = column_indices.get('CustReport1')
            if customer_complaint_column_index:
                customer_complaint_value = RMA_instance.CustomerComplaint
                sheet.cell(row=next_row, column=customer_complaint_column_index).value = customer_complaint_value

            #Update RMA category:
            # Update the "RMA category " column in the NEXT row with a new value
            RMA_category_column_index = column_indices.get('MRA Category')
            if RMA_category_column_index:
                RMA_category_value = RMA_instance.RMAcategory
                sheet.cell(row=next_row, column=RMA_category_column_index).value = RMA_category_value

            #Update Cadex Reply:
            # Update the "Cadex reply " column in the NEXT row with a new value
            Cadex_reply_column_index = column_indices.get('Reply1')
            if Cadex_reply_column_index:
                Cadex_reply_value = RMA_instance.CadexReply
                sheet.cell(row=next_row, column=Cadex_reply_column_index).value = Cadex_reply_value

            #Update RMA condition:
            # Update the "Cadex reply " column in the NEXT row with a new value
            RMA_condition_column_index = column_indices.get('Status')
            if RMA_condition_column_index:
                RMA_condition_value = RMA_instance.RMAcondition
                sheet.cell(row=next_row, column=RMA_condition_column_index).value = RMA_condition_value

            #Update RMA comments:
            # Update the "RMA comments " column in the NEXT row with a new value
            RMA_comments_column_index = column_indices.get('MRAComments1')
            if RMA_comments_column_index:
                RMA_comments_value = RMA_instance.RMAcomments
                sheet.cell(row=next_row, column=RMA_comments_column_index).value = RMA_comments_value

            #Update RMA signature:
            # Update the "RMA comments " column in the NEXT row with a new value
            RMA_signature_column_index = column_indices.get('MRAComments3')
            if RMA_signature_column_index:
                RMA_signature_value = RMA_instance.RMAsignature
                sheet.cell(row=next_row, column=RMA_signature_column_index).value = RMA_signature_value

            #Update RMA status:
            # Update the "RMA status " column in the NEXT row with a new value
            RMA_status_column_index = column_indices.get('Closed')
            if RMA_status_column_index:
                RMA_status_value = RMA_instance.Status
                sheet.cell(row=next_row, column=RMA_status_column_index).value = RMA_status_value

            #Update Decontamination status:
            # Update the "Decontamination status " column in the NEXT row with a new value
            RMA_decontamination_status_column_index = column_indices.get('Decontamination Delaration')
            if RMA_decontamination_status_column_index:
                RMA_decontamination_status_value = RMA_instance.DecontaminationStatus
                sheet.cell(row=next_row, column=RMA_decontamination_status_column_index).value = RMA_decontamination_status_value


            #Update Customer Company name:
            # Update the "RMA status " column in the NEXT row with a new value
            customer_company_name_index = column_indices.get('Company')
            if customer_company_name_index:
                customer_company_name_value = customer_instance.customerCompanyName
                sheet.cell(row=next_row, column=customer_company_name_index).value = customer_company_name_value

            #Update Customer Street info:
            # Update the "Customer Street Info" column in the NEXT row with a new value
            customerStreetInfo_index = column_indices.get('Address1')
            if customerStreetInfo_index:
                customerStreetInfo_value = customer_instance.customerStreetInfo
                sheet.cell(row=next_row, column=customerStreetInfo_index).value = customerStreetInfo_value

            #Update Customer city info:
            # Update the "Customer city" column in the NEXT row with a new value
            customerCity_index = column_indices.get('City')
            if customerCity_index:
                customerCity_value = customer_instance.customerCity
                sheet.cell(row=next_row, column=customerCity_index).value = customer_instance.customerCity

            #Update Customer State info:
            # Update the "Customer State" column in the NEXT row with a new value
            customerState_index = column_indices.get('Prov')
            if customerState_index:
                customerState_value = customer_instance.customerState
                sheet.cell(row=next_row, column=customerState_index).value = customerState_value

            #Update Customer Zip code info:
            # Update the "Customer Zip code" column in the NEXT row with a new value
            customerZipCode_index = column_indices.get('Postal')
            if customerZipCode_index:
                customerZipCode_value = int(customer_instance.customerZipCode)
                sheet.cell(row=next_row, column=customerZipCode_index).value = customerZipCode_value

            #Update Customer country info:
            # Update the "Customer country" column in the NEXT row with a new value
            customerCountry_index = column_indices.get('Country')
            if customerCountry_index:
                customerCountry_value = customer_instance.customerCountry
                sheet.cell(row=next_row, column=customerCountry_index).value = customerCountry_value

            #Update Customer contact info:
            # Update the "Customer contact info" column in the NEXT row with a new value
            customerContactName_index = column_indices.get('Contact')
            if customerContactName_index:
                customerContactName_value = customer_instance._customerContactName
                sheet.cell(row=next_row, column=customerContactName_index).value = customerContactName_value

            #Update Customer Phone info:
            # Update the "Customer Phone info" column in the NEXT row with a new value
            customerPhoneNumber_index = column_indices.get('Phone1')
            if customerPhoneNumber_index:
                customerPhoneNumber_value = customer_instance._customerPhoneNumber
                sheet.cell(row=next_row, column=customerPhoneNumber_index).value = customerPhoneNumber_value

            #Update Customer email info:
            # Update the "Customer email info" column in the NEXT row with a new value
            customerEmail_index = column_indices.get('Email')
            if customerEmail_index:
                customerEmail_value = customer_instance._customerEmail
                sheet.cell(row=next_row, column=customerEmail_index).value = customerEmail_value


            # Save the workbook, preserving the .xlsm extension
            workbook.save(file_path)
        except PermissionError:
            print("Cannot update CustomerDB database. It is likely that somebody has the file open. Permission denied. Please close the Excel sheet and try again.")
        except Exception as e:
            print(f"Error occurred: {e}")
            raise

        return New_RMA_ID

class Timestamp:
    def __init__(self):
        now = datetime.now()
        self.day = now.day
        self.month = now.month
        self.year = now.year

    def get_current_date(self):
        # Return the current date as a datetime object
        return datetime.now()

    @staticmethod
    def get_excel_date_style():
        # Create and return a NamedStyle object for Excel date formatting
        date_style = NamedStyle(name='custom_date_style', number_format='DD-MMM-YYYY')
        return date_style

    def __str__(self):
        # Use a four-digit year for consistency
        return f"Timestamp - Year: {self.year:04d}, Month: {self.month:02d}, Day: {self.day:02d}"

def main():
    # Establish the params
    subdomain = 'company'
    email = 'test@company.com'
    password = 'password goes here'
    client = ZendeskClient(subdomain, email, password)

    # Test the API connection
    client.test_api_connection()

    #Create an instance of RMA
    RMA_instance = RMAmanagement()
    #Create an instance of Customer
    customer_instance = Customer()


    #Fetch customer information based on unique identifier: email address
    user_email = 'dprieur@gettel.com'
    users = client.search_user_by_email(user_email, customer_instance)

    if users:
        for user in users:
            full_address = client.get_organization_address(user['organization_id'], customer_instance) if user['organization_id'] else "No organization"

            # Print user information
            print(f"User ID: {user_info_dict.get('id')}")
            print(f"Name: {user_info_dict.get('name')}")
            print(f"Email: {user_info_dict.get('email')}")
            print(f"Phone: {user_info_dict.get('phone')}")
            print(f"Full Address: {full_address}")

            # Print individual address components
            if full_address:
                print(f"Address: {address_dict.get('address')}")
                print(f"City: {address_dict.get('city')}")
                print(f"State: {address_dict.get('state')}")
                print(f"Zip Code: {address_dict.get('zip_code')}")
                print(f"Country: {address_dict.get('country')}")
    else:
        print("No users found matching the email.")





    #Create a new RMA
    response = input("Is the information above correct? Y or N. If Yes, proceeding to create new RMA ")
    response = response.upper()

    if response == 'Y':
        print("Processing...Please wait...")
        # Create RMA for old excel spreadsheet
        try:
            # Call the method
            RMA_instance.update_excel_with_rma_info(RMA_instance, customer_instance)
            print(RMA_instance)
            print(customer_instance)
        except Exception as e:
            print(f"An error occurred while updating Excel: {e}")
    else:
        print("Please correct information on Zendesk, or key in a valid input and try again")


if __name__ == "__main__":
    main()
